#######################################################################################
#Language_Country File name/Country Name                                              #
#Just find your country language file name and new translate it.                      #
#Then put your language file to ./languages directory and restart App.                #
#Mail me your translation language file and I'll put it in App for others to download.#
#Please note that your language file name(case sensitive) must be the same as under.  #
#######################################################################################
language_ja_JP.ini/Japan
language_es_PE.ini/Peru
language_ja_JP.ini/Japan
language_es_PA.ini/Panama
language_sr_BA.ini/Bosnia and Herzegovina
language_es_GT.ini/Guatemala
language_ar_AE.ini/United Arab Emirates
language_no_NO.ini/Norway
language_sq_AL.ini/Albania
language_ar_IQ.ini/Iraq
language_ar_YE.ini/Yemen
language_pt_PT.ini/Portugal
language_el_CY.ini/Cyprus
language_ar_QA.ini/Qatar
language_mk_MK.ini/Macedonia
language_de_CH.ini/Switzerland
language_en_US.ini/United States
language_fi_FI.ini/Finland
language_en_MT.ini/Malta
language_sl_SI.ini/Slovenia
language_sk_SK.ini/Slovakia
language_tr_TR.ini/Turkey
language_ar_SA.ini/Saudi Arabia
language_en_GB.ini/United Kingdom
language_sr_CS.ini/Serbia and Montenegro
language_en_NZ.ini/New Zealand
language_no_NO.ini/Norway
language_lt_LT.ini/Lithuania
language_es_NI.ini/Nicaragua
language_ga_IE.ini/Ireland
language_fr_BE.ini/Belgium
language_es_ES.ini/Spain
language_ar_LB.ini/Lebanon
language_fr_CA.ini/Canada
language_et_EE.ini/Estonia
language_ar_KW.ini/Kuwait
language_sr_RS.ini/Serbia
language_es_US.ini/United States
language_es_MX.ini/Mexico
language_ar_SD.ini/Sudan
language_in_ID.ini/Indonesia
language_es_UY.ini/Uruguay
language_lv_LV.ini/Latvia
language_pt_BR.ini/Brazil
language_ar_SY.ini/Syria
language_es_DO.ini/Dominican Republic
language_fr_CH.ini/Switzerland
language_hi_IN.ini/India
language_es_VE.ini/Venezuela
language_ar_BH.ini/Bahrain
language_en_PH.ini/Philippines
language_ar_TN.ini/Tunisia
language_de_AT.ini/Austria
language_nl_NL.ini/Netherlands
language_es_EC.ini/Ecuador
language_zh_TW.ini/Taiwan
language_ar_JO.ini/Jordan
language_is_IS.ini/Iceland
language_es_CO.ini/Colombia
language_es_CR.ini/Costa Rica
language_es_CL.ini/Chile
language_ar_EG.ini/Egypt
language_en_ZA.ini/South Africa
language_th_TH.ini/Thailand
language_el_GR.ini/Greece
language_it_IT.ini/Italy
language_hu_HU.ini/Hungary
language_en_IE.ini/Ireland
language_uk_UA.ini/Ukraine
language_pl_PL.ini/Poland
language_fr_LU.ini/Luxembourg
language_nl_BE.ini/Belgium
language_en_IN.ini/India
language_ca_ES.ini/Spain
language_ar_MA.ini/Morocco
language_es_BO.ini/Bolivia
language_en_AU.ini/Australia
language_zh_SG.ini/Singapore
language_es_SV.ini/El Salvador
language_ru_RU.ini/Russia
language_ko_KR.ini/South Korea
language_ar_DZ.ini/Algeria
language_vi_VN.ini/Vietnam
language_sr_ME.ini/Montenegro
language_ar_LY.ini/Libya
language_zh_CN.ini/China
language_be_BY.ini/Belarus
language_zh_HK.ini/Hong Kong
language_iw_IL.ini/Israel
language_bg_BG.ini/Bulgaria
language_mt_MT.ini/Malta
language_es_PY.ini/Paraguay
language_fr_FR.ini/France
language_cs_CZ.ini/Czech Republic
language_it_CH.ini/Switzerland
language_ro_RO.ini/Romania
language_es_PR.ini/Puerto Rico
language_en_CA.ini/Canada
language_de_DE.ini/Germany
language_de_LU.ini/Luxembourg
language_es_AR.ini/Argentina
language_ms_MY.ini/Malaysia
language_hr_HR.ini/Croatia
language_en_SG.ini/Singapore
language_ar_OM.ini/Oman
language_th_TH.ini/Thailand
language_sv_SE.ini/Sweden
language_da_DK.ini/Denmark
language_es_HN.ini/Honduras
