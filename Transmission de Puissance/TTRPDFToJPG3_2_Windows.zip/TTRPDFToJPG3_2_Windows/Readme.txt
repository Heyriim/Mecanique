TTRPdfToJpgAP 3.1
##########################################################################################
Author:Ted Kuo
mail:ted9668@gmail.com

My other mobile Apps:

Android App:
TTR PDF JPG Scanner Converter
https://play.google.com/store/apps/details?id=tw.tn.ted.ttrpdfjpg
Location Address Finder
https://play.google.com/store/apps/details?id=tw.tn.ted.maps
TicTacToe
https://play.google.com/store/apps/details?id=tw.tn.ted
Taiwan Dark Chess
https://play.google.com/store/apps/details?id=tw.tn.ted.chess

iOS App:
Taiwan Dark Chess
https://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=1010566746&mt=8

My blog:
http://tedmyblog.blogspot.com

My Google+:
https://plus.google.com/u/1/+%E9%83%AD%E6%B3%B0%E5%BE%B7
###########################################################################################

License:  GNU General Public License version 3.0 (GPLv3)

	1.Requires JRE.(download from http://java.com/download)

	2.Please direct execute TTRPdfToJpgAP3.jar(Windows).

	3.TTR PDF To JPG is an application that can Convert PDF File to JPG,PNG,GIF,BMP,TIF images.

	4.MultiLanguages Supported.(English,Taiwan,France,Bolivia)
	
	5.If you would like to translate App's Language for your country Language,please read this file ./ReadMe_World_Language_Country.txt.

###########################################################################################

3.2 version new added feature:

	1.Thailand Language file added.
	
3.1 version new added feature:

	1.Magnification can be entered <= 10 float, ex: 0.5
	
	2.Brazil,Hungary Languages files added.
	
	3.Some bugs fixed.
	
Used Library:
	1.JMuPdf https://sourceforge.net/projects/jmupdf/
	
################################################

Language Help

	Taiwan	Ted Kuo <ted9668@gmail.com>

	France	Tony Calvez <tony.calvez@hotmail.fr>
	
	Bolivia Edwin Mancilla Caballero <Emancilla91@outlook.com>
	
	Brazil  Guilherme Sacramoni <guilhermesacramoni@gmail.com>
	
	Hungary Szekeres Tamás <szekeres.tamas@hotmail.hu>
	
	Thailand Punth Punth <punth1@gmail.com>
	
	
	
	